package com.example.productoapi;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ProductoapiApplicationTests {

	@Test
	void contextLoads() {
	}

}
