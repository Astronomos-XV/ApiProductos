package com.example.productoapi.repository;

import com.example.productoapi.model.Producto; // Esta línea debe estar presente
import org.springframework.data.jpa.repository.JpaRepository;

public interface ProductoRepository extends JpaRepository<Producto, Long> {
}